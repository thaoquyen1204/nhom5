const express = require('express'); 
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const exphdbs =  require('express-handlebars');
//const userRouter = require('./routes/userRoutes');
const userController = require('./controllers/userController');
const { route } = require('./controllers/userController');
const url ="mongodb+srv://quyen1204:quyen1204@cluster0.dfistiw.mongodb.net/dbQuanLy?retryWrites=true&w=majority";
const app = express(); 
const port = 8080; 
  
app.use(bodyParser.urlencoded({
    extended:true
}));
app.use(bodyParser.json());
app.use(express.static('views'));
app.engine('.hbs', exphdbs.engine({ extname: '.hbs', defaultLayout: "main"}));
app.set('view engine', '.hbs');
app.use(express.json());


mongoose.connect(url,{useUnifiedTopology:true, useNewUrlParser:true});

//app.use(userRouter);
app.use('/user',userController);

app.listen(port, function(){
    console.log("Your app running on port " + port);
})



