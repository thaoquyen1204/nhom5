const express = require('express');
const userModel = require('../models/user');
const app = express();

app.get('/', (req,res) => {
    res.render('users/addOrEdit.hbs',{
        viewTitle:"Quản lý thông tin"
    });
});


app.post('/add', async (req,res) => {
    console.log(req.body);
    if(req.body.id == ''){
        //add user 
        addRecord(req,res);
    }else{
        //update user
        updateRecord(req,res);
    }
    
});

app.get('/list', (req,res) => {
    userModel.find({}).then(users => {
        res.render('users/view-users.hbs',{
            users: users.map(user => user.toJSON()) 
       });
    })
   
});
//thu

function addRecord(req,res){
    const u = new userModel(req.body);
    try{
         u.save();
        //res.send(u);
        res.render('users/addOrEdit.hbs',{
            viewTitle:"Thêm thành viên thành công"
        });
    } catch (error) {
        res.status(500).send(error);
    }
}

function updateRecord(req,res){
    userModel.findOneAndUpdate({_id:req.body.id},req.body,{new:true},(err,doc)=>{
        if(!err){
            res.redirect('/user/list')
        }else{
            console.log(err);
            res.render('users/addOrEdit.hbs',{
                viewTitle:"Lỗi cập nhật rồi"
            });
        }
    })
}
//app.get('/list', (req,res) => {
//    res.render('users/view-users.hbs',{
//        viewTitle:"Danh sách thông tin"
//   });
//});

app.get('/list', (req,res) => {
    userModel.find({}).then(users => {
        res.render('users/view-users.hbs',{
            users: users.map(user => user.toJSON()) 
       });
    })
   
});

app.get('/edit/:id' , (req,res) => {
    userModel.findById(req.params.id,(err , user) =>{
        if(!err){
            res.render('users/addOrEdit.hbs' ,{
                viewTitle:"Cập nhật thông tin",
               user:user.toJSON() 
            });
        }        
    })
});



app.get('/delete/:id' , async(req,res) => {
    try {
        const user = await userModel.findByIdAndDelete(req.params.id,req.body);  
        if(!user) res.status(404).send("khong tim thay");
        else{
            res.redirect('/user/list')
        }
        //res.status(200).send();
    } catch (error) {
        res.status(500).send(error);
    }
    
});

module.exports = app;